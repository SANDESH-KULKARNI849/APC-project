#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "apc.h"

//int sign=0;

void digit_to_list(Dlist **head1,Dlist **tail1,Dlist **head2,Dlist **tail2,char *argv[])
{
    char *str1=argv[1];
    int digit1,digit2,i=0;
    while(str1[i] != '\0')
    {
        digit1=str1[i]-'0';
        insert_last(head1,tail1,digit1);
        i++;
    }

    char *str2=argv[3];
    int j=0;
    while(str2[j] != '\0')
    {
        digit2=str2[j]-'0';
        insert_last(head2,tail2,digit2);
        j++;
    }
}

void string_to_list(Dlist **head,Dlist **tail,const char *str)
{
    int i=0;
    while(str[i]!='\0')
    {
        int digit = str[i]-'0';
        insert_last(head,tail,digit);
        i++;
    }
}
void digit_to_list_sub(Dlist **head1,Dlist **tail1,Dlist **head2,Dlist **tail2,char *argv[])
{
    int cnt1=strlen(argv[1]);
    int cnt2=strlen(argv[3]);
    int res=strcmp(argv[1],argv[3]);


    if(cnt1 > cnt2 && (res>0) || (cnt1 == cnt2 && res > 0))
    {
        string_to_list(head1,tail1,argv[1]);
        string_to_list(head2,tail2,argv[3]);
        sign=0;
    }
    else if(cnt1 < cnt2 && (res<0) || (cnt1 == cnt2 && res<0))
    {
        string_to_list(head1,tail1,argv[3]);
        string_to_list(head2,tail2,argv[1]);
        sign=1;
    }
    else
    {
        sign=0;
        string_to_list(head1,tail1,argv[1]);
        string_to_list(head2,tail2,argv[3]);
    }
}

int insert_last(Dlist **head, Dlist **tail, int data)
{
    Dlist *new=malloc(sizeof(Dlist));
    if(new == NULL)
    {
        return FAILURE;
    }
    new->data=data;
    new->prev=NULL;
    new->next=NULL;
    
    if(*head == NULL)
    {
        *head=new;
        *tail=new;
        return SUCCESS;
    }
    else
    {
        new->prev=*tail;
        (*tail)->next=new;
        *tail=new;
        return SUCCESS;
    }
}

int insert_first(Dlist **headR, Dlist **tailR, int data)
{
    Dlist *new=malloc(sizeof(Dlist));
    if(new == NULL)
    {
        return FAILURE;
    }
    new->data=data;
    new->prev=NULL;
    new->next=NULL;
    if(*tailR == NULL)//Either head or tail
    {
        *headR=new;
        *tailR=new;
        return SUCCESS;
    }
    else
    {
        new->next=*headR;
        (*headR)->prev=new;
        *headR=new;
        return SUCCESS;
    }
}

int delete_list(Dlist **head, Dlist **tail)
{
    if(*tail == NULL)
    {
        return FAILURE;
    }
    Dlist *temp=*head;
    while(temp != NULL)
    {
        temp=temp->next;
        free(*head);
        *head=temp;
    }
    *head=NULL;
    *tail=NULL;
    return SUCCESS;
}

void copy_list(Dlist *headB, Dlist **head1, Dlist **tail1) 
{
    Dlist *temp = headB;

    while (temp != NULL) 
    {
        insert_last(head1,tail1,temp->data);
        temp = temp->next;
    }
}

void remove_zeros(Dlist **headR, Dlist **tailR) 
{
    while(*headR != NULL && (*headR)->data == 0) 
    {
        Dlist *temp = *headR;
        *headR = (*headR)->next;
        if(*headR != NULL) 
        {
            (*headR)->prev = NULL;
        }
        else 
        {
            *tailR = NULL; // If the list becomes empty
        }
        free(temp);
    }

    // If the list becomes empty, add a single zero node
    if(*headR == NULL) 
    {
        insert_first(headR, tailR, 0);
    }
}

void remove_leading_zeros(Dlist **head, Dlist **tail)
{
    while (*head != NULL && (*head)->data == 0 && (*head)->next != NULL)
    {
        Dlist *temp = *head;
        *head = (*head)->next;
        (*head)->prev = NULL;
        free(temp);
    }
    // If the number is 0, ensure it's represented as a single node
    if (*head != NULL && (*head)->next == NULL && (*head)->data == 0)
    {
        *tail = *head;
    }
}