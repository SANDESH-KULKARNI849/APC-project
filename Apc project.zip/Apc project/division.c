#include "apc.h"
#include <stddef.h>
#include <stdio.h>

int division(Dlist **head1, Dlist **tail1, Dlist **head2, Dlist **tail2, Dlist **headR, Dlist **tailR)
{
    if (compare_lists(head1, head2) < 0)
    {
        insert_last(headR, tailR, 0);
        printf("Division Result => 0\n");
        return 0;
    }

    if (compare_lists(head1, head2) == 0)
    {
        insert_last(headR, tailR, 1);
        printf("Division Result => 1\n");
        return 0;
    }

    Dlist *headTemp = NULL, *tailTemp = NULL; // To store sub result
    Dlist *headQuotient = NULL, *tailQuotient = NULL; // To store the count
    int count = 0;

    while (compare_lists(head1, head2) >= 0)
    {
        subtraction(head1,tail1,head2,tail2,&headTemp,&tailTemp);
        count++;
        delete_list(head1, tail1);
        *head1 = headTemp;
        *tail1 = tailTemp;
        headTemp = NULL;
        tailTemp = NULL;
    }

    insert_first(&headQuotient, &tailQuotient, count);

    *headR = headQuotient; // Assign quotient to headR and tailR
    *tailR = tailQuotient;

    remove_zeros(headR, tailR);

    printf("Division Result => ");
    Dlist *temp = *headR;
    while (temp != NULL)
    {
        printf("%d", temp->data);
        temp = temp->next;
    }
    printf("\n");
}

int compare_lists(Dlist **head1, Dlist **head2)
{
    int len1=0,len2=0;
    Dlist *temp1 = *head1, *temp2 = *head2;
    while(temp1 != NULL)
    {
        len1++;
        temp1 = temp1->next;
    }
    while(temp2 != NULL)
    {
        len2++;
        temp2 = temp2->next;
    }

    if (len1 > len2) return 1;
    if (len1 < len2) return -1;

    // Reset pointers 
    temp1 = *head1;
    temp2 = *head2;

    while (temp1 != NULL && temp2 != NULL)
    {
        if (temp1->data > temp2->data) return 1;
        if (temp1->data < temp2->data) return -1;
        temp1 = temp1->next;
        temp2 = temp2->next;
    }
    return 0; // Numbers are equal
}