#include "apc.h"
#include <stddef.h>
#include <stdio.h>

int sign=0;

int subtraction(Dlist **head1, Dlist **tail1, Dlist **head2, Dlist **tail2, Dlist **headR,Dlist **tailR)
{
	Dlist *temp1=*tail1;
	Dlist *temp2=*tail2;
	int borrow=0;
	int num1,num2,result=0;
    while(temp1 != NULL || temp2 != NULL)
    {
        num1 = (temp1 != NULL) ? temp1->data : 0;
        num2 = (temp2 != NULL) ? temp2->data : 0;
        num1=num1-borrow;
        if(num1 >= num2)
        {
            
            result=num1-num2;
            borrow=0;
        }
        else
        {
            result=(num1+10)-num2;
            borrow=1;
        }

        if(borrow == 1)
        {
            num1=num1-1;
            borrow=0;
        }
        insert_first(headR,tailR,result);
        if(temp1 != NULL)
		{
			temp1 = temp1->prev;
		}
        if(temp2 != NULL) 
		{
			temp2 = temp2->prev;
		}
    }
    remove_zeros(headR, tailR);

    Dlist *temp=*headR;
    
	printf("Subtraction Result => ");
    if (sign == 1) 
    {
        printf("-");
    }
	while(temp != NULL)
	{
		printf("%d",temp->data);
		temp=temp->next;
	}
	printf("\n");
}