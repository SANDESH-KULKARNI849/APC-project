#include "apc.h"
#include <stddef.h>
#include <stdio.h>

int multiplication(Dlist **head1, Dlist **tail1, Dlist **head2, Dlist **tail2, Dlist **headR, Dlist **tailR)
{
    Dlist *headR2 = NULL, *tailR2 = NULL;
    int num1, num2, cnt = 0, res = 0, carry = 0;
    Dlist *temp1 = *tail1;
    Dlist *temp2 = *tail2;

    while (temp2 != NULL)
    {
        carry = 0;
        temp1 = *tail1;
        headR2 = NULL;
        tailR2 = NULL;
        // Multiply each digit of the first number with the current digit of the second number
        while (temp1 != NULL)
        {
            num1 = temp1->data;
            num2 = temp2->data;
            res = num1 * num2 + carry;
            carry = res / 10;
            insert_first(&headR2, &tailR2, res % 10);
            temp1 = temp1->prev;
        }

        if (carry > 0)
        {
            insert_first(&headR2, &tailR2, carry);
        }

        // Adding zeros
        for (int i = 0; i < cnt; i++)
        {
            insert_last(&headR2, &tailR2, 0);
        }
        Dlist *tempHead = NULL, *tempTail = NULL;
        addition(headR, tailR, &headR2, &tailR2, &tempHead, &tempTail);

        // Update the result with the new sum
        delete_list(headR, tailR);
        *headR = tempHead;
        *tailR = tempTail;

        delete_list(&headR2, &tailR2);

        // Move to the next digit of the second number
        temp2 = temp2->prev;
        cnt++;
    }

    // Print the final multiplication result
    printf("Multiplication Result => ");
    Dlist *temp = *headR;
    while (temp != NULL)
    {
        printf("%d", temp->data);
        temp = temp->next;
    }
    printf("\n");

    return SUCCESS;
}