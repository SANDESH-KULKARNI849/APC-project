#include "apc.h"
#include <stddef.h>
#include <stdio.h>


int addition(Dlist **head1, Dlist **tail1, Dlist **head2, Dlist **tail2, Dlist **headR, Dlist **tailR) {
    Dlist *temp1 = *tail1;
    Dlist *temp2 = *tail2;
    int carry = 0;
    int num1, num2, sum = 0;

    while (temp1 != NULL || temp2 != NULL) {
        num1 = (temp1 != NULL) ? temp1->data : 0;
        num2 = (temp2 != NULL) ? temp2->data : 0;

   
        sum = num1 + num2 + carry;
        int data = sum % 10;
        carry = sum / 10;

        insert_first(headR, tailR, data);
        if (temp1 != NULL) {
            temp1 = temp1->prev;
        }
        if (temp2 != NULL) {
            temp2 = temp2->prev;
        }
    }
    if (carry > 0) {
        insert_first(headR, tailR, carry);
    }
    Dlist *temp = *headR;
    printf("Addition Result => ");
    while (temp != NULL) {
        printf("%d", temp->data);
        temp = temp->next;
    }
    printf("\n");

    return 0;
}
